<?php

// Start the session (if not already started)
session_start();

function check_login($conn)
{
    if (isset($_SESSION['user_id'])) {
        $id = $_SESSION['user_id'];

        // Using prepared statement to prevent SQL injection
        $query = "SELECT * FROM users WHERE user_id = ? LIMIT 1"; // Assuming 'users' is the correct table name
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "i", $id); // "i" is the type for an integer
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);
            return $user_data;
        }
    }
    // Redirect to login if not logged in
    header("Location: Login.html");
    die;
}

function random_num($length)
{
    $text = "";
    if ($length < 5) {
        $length = 5;
    }
    $len = rand(4, $length);

    for ($i = 0; $i < $len; $i++) {
        $text .= rand(0, 9); // Generate random number
    }
    return $text; // Move the return statement outside the loop
}
?>

